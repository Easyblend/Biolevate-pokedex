
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("clip", {
  on(channel, callback) {
    const allowed = ["state", "activity"];
    if (!allowed.includes(channel)) return;
    ipcRenderer.on(channel, (_event, payload) => callback(payload));
  },

  connect(ip) {
    return ipcRenderer.invoke("connect-to-ip", ip);
  },

  copyHistoryItem(id) {
    return ipcRenderer.invoke("copy-history-item", id);
  },

  deleteHistoryItem(id) {
    return ipcRenderer.invoke("delete-history-item", id);
  },

  clearHistory() {
    return ipcRenderer.invoke("clear-history");
  }
});
