
# Clip v1.3

Clip syncs clipboard contents between laptops over the same LAN.

## What's new in v1.3

- Text clipboard sync
- Image clipboard sync
- **Finder file clipboard sync on macOS**
- Copy a file in Finder on Mac A
- Clip transfers the actual file
- On Mac B, `Cmd+V` in Finder pastes the file into the current folder
- Multiple selected files are supported on macOS
- File history stores staged copies so the file remains available
- 50-item local history
- Direct IP WebSocket connection
- No cloud backend

## macOS file support

The app builds a tiny Swift pasteboard helper the first time file clipboard functionality is used.

If Swift compilation fails, install Apple's Command Line Tools:

```bash
xcode-select --install
```

Then restart Clip.

## Run

```bash
npm install
npm start
```

Run Clip on both laptops.

On each laptop, enter the other laptop's LAN IP and click Connect.

Example:

Mac:
10.100.195.60

Other laptop:
10.100.195.65

Port:
45821

## Important

This is a LAN utility. There is currently no authentication or encryption.

File transfers are currently JSON/base64 encoded and limited to 100 MB per file. This keeps the implementation simple for the MVP but is not ideal for very large files.

macOS Finder file clipboard support is implemented natively.

Windows currently retains text/image functionality; native Explorer file clipboard support is not yet implemented in this build.
