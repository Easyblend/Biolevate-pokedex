# Clip — LAN clipboard sync MVP

## What it does
Run Clip on two laptops connected to the same Wi-Fi/network.

- Copy text on Laptop A → it appears in Laptop B's clipboard.
- Copy an image on Laptop A → it appears in Laptop B's clipboard.
- Both laptops run the exact same app.
- No cloud server or account is required.
- LAN discovery uses UDP broadcast.
- Clipboard transport uses WebSockets.

## Requirements
- Node.js 20+ recommended
- macOS / Windows / Linux
- Both laptops on the same local network

## Run
```bash
npm install
npm start
```

Run the same commands on the second laptop.

## If the laptops don't see each other
The OS firewall may be blocking UDP 45822 and TCP 45821. Allow Clip/Node on the private/local network.

## Next improvements
- Pairing/security key
- Encrypted WebSocket transport
- Clipboard history
- System tray/background mode
- Better image compression/chunking for large images
- Auto-start
- Cross-platform packaging/installers
