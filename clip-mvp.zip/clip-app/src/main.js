const { app, BrowserWindow, clipboard, nativeImage } = require("electron");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const dgram = require("dgram");
const { WebSocketServer, WebSocket } = require("ws");

const WS_PORT = 45821;
const DISCOVERY_PORT = 45822;
const DISCOVERY_INTERVAL = 2500;
const CLIPBOARD_POLL = 400;
const DEVICE_ID = crypto.randomUUID();
const DEVICE_NAME = os.hostname();

let win;
let wss;
let discovery;
let peers = new Map();
let lastSentHash = "";
let suppressUntil = 0;

function sendUI(type, data = {}) {
  if (win && !win.isDestroyed()) win.webContents.send(type, data);
}

function hash(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function localIPs() {
  const result = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const n of list || []) {
      if (n.family === "IPv4" && !n.internal) result.push(n.address);
    }
  }
  return result;
}

function startWebSocketServer() {
  wss = new WebSocketServer({ port: WS_PORT, host: "0.0.0.0" });

  wss.on("connection", (socket) => {
    socket.on("message", (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.type === "hello") {
          sendUI("peer-update", { id: msg.deviceId, name: msg.name, ip: msg.ip || "LAN" });
        }
        if (msg.type === "clipboard" && msg.source !== DEVICE_ID) {
          applyClipboard(msg);
        }
      } catch {}
    });
  });

  wss.on("error", (err) => sendUI("status", { text: `WebSocket error: ${err.message}` }));
}

function startDiscovery() {
  discovery = dgram.createSocket("udp4");

  discovery.on("error", () => {
    try { discovery.close(); } catch {}
    setTimeout(startDiscovery, 2000);
  });

  discovery.on("message", (buf, rinfo) => {
    try {
      const msg = JSON.parse(buf.toString());
      if (msg.type !== "clip-discovery" || msg.deviceId === DEVICE_ID) return;

      const ip = rinfo.address;
      peers.set(msg.deviceId, { name: msg.name, ip, lastSeen: Date.now() });

      sendUI("peer-update", { id: msg.deviceId, name: msg.name, ip });
      connectToPeer(msg.deviceId, ip);
    } catch {}
  });

  discovery.bind(DISCOVERY_PORT, "0.0.0.0", () => {
    discovery.setBroadcast(true);
    broadcastDiscovery();
  });

  setInterval(broadcastDiscovery, DISCOVERY_INTERVAL);
  setInterval(cleanPeers, 5000);
}

function broadcastDiscovery() {
  if (!discovery) return;
  const packet = Buffer.from(JSON.stringify({
    type: "clip-discovery",
    deviceId: DEVICE_ID,
    name: DEVICE_NAME
  }));
  discovery.send(packet, 0, packet.length, DISCOVERY_PORT, "255.255.255.255");
}

function cleanPeers() {
  const now = Date.now();
  for (const [id, peer] of peers) {
    if (now - peer.lastSeen > 8000) {
      peers.delete(id);
      sendUI("peer-remove", { id });
    }
  }
}

function connectToPeer(id, ip) {
  const peer = peers.get(id);
  if (!peer || peer.socket?.readyState === WebSocket.OPEN || peer.connecting) return;

  peer.connecting = true;
  const socket = new WebSocket(`ws://${ip}:${WS_PORT}`);

  socket.on("open", () => {
    peer.socket = socket;
    peer.connecting = false;
    socket.send(JSON.stringify({
      type: "hello",
      deviceId: DEVICE_ID,
      name: DEVICE_NAME
    }));
    sendUI("peer-update", { id, name: peer.name, ip, connected: true });
  });

  socket.on("close", () => {
    peer.socket = null;
    peer.connecting = false;
    sendUI("peer-update", { id, name: peer.name, ip, connected: false });
  });

  socket.on("error", () => {
    peer.connecting = false;
  });

  socket.on("message", (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === "clipboard") applyClipboard(msg);
    } catch {}
  });
}

function broadcastClipboard(payload) {
  const message = JSON.stringify({
    type: "clipboard",
    source: DEVICE_ID,
    ...payload
  });

  for (const peer of peers.values()) {
    if (peer.socket?.readyState === WebSocket.OPEN) {
      peer.socket.send(message);
    }
  }
}

function applyClipboard(msg) {
  suppressUntil = Date.now() + 1200;

  if (msg.kind === "text") {
    clipboard.writeText(msg.data);
    sendUI("received", { kind: "text", preview: msg.data.slice(0, 80) });
  } else if (msg.kind === "image") {
    const image = nativeImage.createFromDataURL(msg.data);
    clipboard.writeImage(image);
    sendUI("received", { kind: "image", preview: "Image received" });
  }
}

function pollClipboard() {
  if (Date.now() < suppressUntil) return;

  const text = clipboard.readText();
  if (text) {
    const h = hash("text:" + text);
    if (h !== lastSentHash) {
      lastSentHash = h;
      broadcastClipboard({ kind: "text", data: text });
      sendUI("sent", { kind: "text", preview: text.slice(0, 80) });
    }
    return;
  }

  const image = clipboard.readImage();
  if (!image.isEmpty()) {
    const png = image.toPNG();
    const h = hash(Buffer.concat([Buffer.from("image:"), png]));
    if (h !== lastSentHash) {
      lastSentHash = h;
      broadcastClipboard({
        kind: "image",
        data: `data:image/png;base64,${png.toString("base64")}`
      });
      sendUI("sent", { kind: "image", preview: "Image copied" });
    }
  }
}

function createWindow() {
  win = new BrowserWindow({
    width: 560,
    height: 620,
    minWidth: 420,
    minHeight: 500,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile(path.join(__dirname, "index.html"));
}

app.whenReady().then(() => {
  createWindow();
  startWebSocketServer();
  startDiscovery();
  setInterval(pollClipboard, CLIPBOARD_POLL);

  sendUI("device-info", {
    name: DEVICE_NAME,
    ips: localIPs(),
    port: WS_PORT
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
