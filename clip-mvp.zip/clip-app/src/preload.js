const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("clip", {
  on: (channel, callback) => {
    const allowed = ["device-info", "peer-update", "peer-remove", "sent", "received", "status"];
    if (allowed.includes(channel)) {
      ipcRenderer.on(channel, (_, data) => callback(data));
    }
  }
});
