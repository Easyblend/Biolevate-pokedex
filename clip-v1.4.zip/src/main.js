
const {
  app,
  BrowserWindow,
  clipboard,
  nativeImage,
  ipcMain,
  dialog
} = require("electron");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const os = require("os");
const { execFile } = require("child_process");
const WebSocket = require("ws");

const WS_PORT = 45821;
const CLIPBOARD_POLL_MS = 400;
const MAX_HISTORY = 50;
const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100 MB per file

let mainWindow;
let server;
let peers = new Set();
let deviceId = crypto.randomUUID();
let lastClipboardFingerprint = null;
let suppressNextClipboardPoll = false;

const historyFile = () => path.join(app.getPath("userData"), "clipboard-history.json");
const historyDir = () => path.join(app.getPath("userData"), "history-files");

let history = [];

function ensureDirs() {
  fs.mkdirSync(path.dirname(historyFile()), { recursive: true });
  fs.mkdirSync(historyDir(), { recursive: true });
}

function safeFilename(name) {
  return String(name || "file").replace(/[\/\\:*?"<>|]/g, "_").slice(0, 180);
}

function hashData(kind, data) {
  return crypto.createHash("sha256").update(`${kind}:${data}`).digest("hex");
}

function fileFingerprint(files) {
  return crypto.createHash("sha256")
    .update(files.map(f => `${f.name}:${f.size}:${f.sha256 || ""}`).join("|"))
    .digest("hex");
}

function loadHistory() {
  ensureDirs();
  try {
    if (!fs.existsSync(historyFile())) return;
    const parsed = JSON.parse(fs.readFileSync(historyFile(), "utf8"));
    history = Array.isArray(parsed) ? parsed : [];
  } catch {
    history = [];
  }
}

function saveHistory() {
  ensureDirs();
  fs.writeFileSync(historyFile(), JSON.stringify(history, null, 2));
}

function sendToRenderer(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, payload);
  }
}

function activity(message) {
  sendToRenderer("activity", {
    message,
    timestamp: new Date().toISOString()
  });
}

function state() {
  return {
    hostname: os.hostname(),
    deviceId,
    port: WS_PORT,
    peers: [...peers].map(p => ({
      address: p.address,
      state: p.ws.readyState
    })),
    history
  };
}

function pushState() {
  sendToRenderer("state", state());
}

function addHistoryItem(item, shouldBroadcast = true) {
  if (!item || !item.kind) return false;

  if (item.kind === "file") {
    if (!Array.isArray(item.files) || item.files.length === 0) return false;
    item.fingerprint = item.fingerprint || fileFingerprint(item.files);
  } else {
    item.fingerprint = item.fingerprint || hashData(item.kind, item.data || "");
  }

  const duplicate = history.find(x => x.fingerprint === item.fingerprint);
  if (duplicate) return false;

  history.unshift(item);
  history = history.slice(0, MAX_HISTORY);
  saveHistory();
  pushState();

  if (shouldBroadcast) {
    broadcast({
      type: "history-item",
      item
    });
  }

  return true;
}

function removeHistoryItem(id) {
  const item = history.find(x => x.id === id);
  history = history.filter(x => x.id !== id);

  if (item?.kind === "file" && Array.isArray(item.files)) {
    for (const f of item.files) {
      if (f.localPath && f.localPath.startsWith(historyDir())) {
        try { fs.unlinkSync(f.localPath); } catch {}
      }
    }
  }

  saveHistory();
  pushState();
}

function clearHistory() {
  for (const item of history) {
    if ((item.kind === "file" && Array.isArray(item.files)) || (item.kind === "image-file" && item.file)) {
      const files = item.kind === "image-file" ? [item.file] : item.files;
      for (const f of files || []) {
        if (f?.localPath && f.localPath.startsWith(historyDir())) {
          try { fs.unlinkSync(f.localPath); } catch {}
        }
      }
    }
  }

  history = [];
  saveHistory();
  pushState();
}

function broadcast(message, except = null) {
  const payload = JSON.stringify(message);

  for (const peer of peers) {
    if (peer === except) continue;
    if (peer.ws.readyState === WebSocket.OPEN) {
      try {
        peer.ws.send(payload);
      } catch {}
    }
  }
}

function sendHistoryToPeer(peer) {
  try {
    peer.ws.send(JSON.stringify({
      type: "history-sync",
      items: history
    }));
  } catch {}
}

function makePeer(ws, address) {
  const peer = { ws, address };
  peers.add(peer);

  ws.on("close", () => {
    peers.delete(peer);
    activity(`Disconnected: ${address}`);
    pushState();
  });

  ws.on("error", () => {});

  ws.on("message", raw => {
    handleMessage(peer, raw.toString());
  });

  ws.send(JSON.stringify({
    type: "hello",
    deviceId,
    hostname: os.hostname()
  }));

  sendHistoryToPeer(peer);
  activity(`Connected: ${address}`);
  pushState();

  return peer;
}

function startWebSocketServer() {
  server = new WebSocket.Server({ host: "0.0.0.0", port: WS_PORT });

  server.on("connection", (ws, req) => {
    const address = req.socket.remoteAddress || "unknown";
    makePeer(ws, address);
  });

  server.on("listening", () => {
    const addr = server.address();
    activity(`Clip server listening on port ${addr.port}`);
    pushState();
  });

  server.on("error", err => {
    activity(`Server error: ${err.message}`);
  });
}

function connectToIP(ip) {
  ip = String(ip || "").trim();
  if (!ip) return { ok: false, error: "Enter an IP address." };

  const url = `ws://${ip}:${WS_PORT}`;
  activity(`Connecting to ${url}...`);

  const ws = new WebSocket(url);

  ws.on("open", () => {
    makePeer(ws, ip);
  });

  ws.on("error", err => {
    activity(`Connection failed: ${err.message}`);
  });

  return { ok: true };
}

function copyFileIntoHistory(filePath) {
  const stat = fs.statSync(filePath);
  if (!stat.isFile()) throw new Error("Not a file.");
  if (stat.size > MAX_FILE_SIZE) {
    throw new Error(`${path.basename(filePath)} is larger than 100 MB.`);
  }

  const id = crypto.randomUUID();
  const filename = safeFilename(path.basename(filePath));
  const destination = path.join(historyDir(), `${id}-${filename}`);

  fs.copyFileSync(filePath, destination);

  const sha256 = crypto
    .createHash("sha256")
    .update(fs.readFileSync(destination))
    .digest("hex");

  return {
    id,
    name: filename,
    size: stat.size,
    sha256,
    localPath: destination
  };
}

function copyFilesToHistory(filePaths) {
  const files = [];
  for (const filePath of filePaths) {
    try {
      files.push(copyFileIntoHistory(filePath));
    } catch (err) {
      activity(`Could not copy ${path.basename(filePath)}: ${err.message}`);
    }
  }
  return files;
}

/*
 * macOS pasteboard bridge:
 * Electron's clipboard API exposes image/text, but Finder file copies are
 * represented as file URLs on NSPasteboard. We use a tiny Swift helper
 * compiled on first use to read/write file URLs.
 *
 * The helper is intentionally source-generated here so the project has no
 * external runtime dependency.
 */
const macHelperSource = `
import Foundation
import AppKit

let pasteboard = NSPasteboard.general

func mimeForType(_ type: NSPasteboard.PasteboardType) -> String? {
    switch type.rawValue {
    case "public.png": return "image/png"
    case "public.jpeg": return "image/jpeg"
    case "public.webp": return "image/webp"
    case "com.compuserve.gif": return "image/gif"
    case "public.tiff": return "image/tiff"
    case "com.microsoft.bmp": return "image/bmp"
    default: return nil
    }
}

func extensionForMime(_ mime: String) -> String {
    switch mime {
    case "image/png": return "png"
    case "image/jpeg": return "jpg"
    case "image/webp": return "webp"
    case "image/gif": return "gif"
    case "image/tiff": return "tiff"
    case "image/bmp": return "bmp"
    default: return "img"
    }
}

if CommandLine.arguments.count >= 2 {
    let command = CommandLine.arguments[1]

    if command == "read" {
        let fileURLType = NSPasteboard.PasteboardType("public.file-url")
        let types = pasteboard.types ?? []

        if types.contains(fileURLType) {
            let urls = pasteboard.readObjects(forClasses: [NSURL.self], options: [
                NSPasteboard.ReadingOptionKey.urlReadingFileURLsOnly: true
            ]) as? [URL] ?? []

            for url in urls {
                print(url.path)
            }
        }
    }

    if command == "read-image" {
        let preferredTypes = [
            NSPasteboard.PasteboardType("public.png"),
            NSPasteboard.PasteboardType("public.jpeg"),
            NSPasteboard.PasteboardType("public.webp"),
            NSPasteboard.PasteboardType("com.compuserve.gif"),
            NSPasteboard.PasteboardType("public.tiff"),
            NSPasteboard.PasteboardType("com.microsoft.bmp")
        ]

        for type in preferredTypes {
            if let data = pasteboard.data(forType: type),
               let mime = mimeForType(type) {
                let base64 = data.base64EncodedString()
                let ext = extensionForMime(mime)
                print("\\(mime)|\\(ext)|\\(base64)")
                exit(0)
            }
        }
    }

    if command == "write" && CommandLine.arguments.count >= 3 {
        let paths = Array(CommandLine.arguments.dropFirst(2))
        pasteboard.clearContents()

        let urls = paths.map { URL(fileURLWithPath: $0) }
        pasteboard.writeObjects(urls as [NSURL])
    }

    if command == "write-image-file" && CommandLine.arguments.count >= 3 {
        let imagePath = CommandLine.arguments[2]
        let imageURL = URL(fileURLWithPath: imagePath)

        pasteboard.clearContents()

        // Put the actual file URL on the pasteboard so Finder sees this
        // as a file that can be pasted.
        pasteboard.writeObjects([imageURL as NSURL])

        // Also put the image bytes on the pasteboard so image-aware apps
        // such as browsers and chat applications can paste the image itself.
        if let data = try? Data(contentsOf: imageURL) {
            let ext = imageURL.pathExtension.lowercased()
            let type: NSPasteboard.PasteboardType

            switch ext {
            case "png":
                type = NSPasteboard.PasteboardType("public.png")
            case "jpg", "jpeg":
                type = NSPasteboard.PasteboardType("public.jpeg")
            case "webp":
                type = NSPasteboard.PasteboardType("public.webp")
            case "gif":
                type = NSPasteboard.PasteboardType("com.compuserve.gif")
            case "tif", "tiff":
                type = NSPasteboard.PasteboardType("public.tiff")
            case "bmp":
                type = NSPasteboard.PasteboardType("com.microsoft.bmp")
            default:
                type = NSPasteboard.PasteboardType("public.data")
            }

            pasteboard.setData(data, forType: type)
        }
    }
}
`;


let helperPath = null;

function ensureMacHelper() {
  if (process.platform !== "darwin") return null;

  ensureDirs();
  helperPath = path.join(app.getPath("userData"), "clip-pasteboard-helper.swift");
  const binaryPath = path.join(app.getPath("userData"), "clip-pasteboard-helper");

  if (!fs.existsSync(binaryPath)) {
    fs.writeFileSync(helperPath, macHelperSource);
    try {
      require("child_process").execFileSync(
        "swiftc",
        ["-O", helperPath, "-o", binaryPath],
        { stdio: "ignore" }
      );
    } catch (err) {
      activity("Could not build macOS file clipboard helper. Install Xcode Command Line Tools.");
      return null;
    }
  }

  return binaryPath;
}

function readMacFileClipboard() {
  if (process.platform !== "darwin") return [];

  const binary = ensureMacHelper();
  if (!binary) return [];

  try {
    const output = require("child_process").execFileSync(binary, ["read"], {
      encoding: "utf8",
      timeout: 1500
    });

    return output
      .split(/\r?\n/)
      .map(x => x.trim())
      .filter(Boolean)
      .filter(x => fs.existsSync(x));
  } catch {
    return [];
  }
}


function readMacImageClipboard() {
  if (process.platform !== "darwin") return null;

  const binary = ensureMacHelper();
  if (!binary) return null;

  try {
    const output = require("child_process").execFileSync(binary, ["read-image"], {
      encoding: "utf8",
      timeout: 1500,
      maxBuffer: 100 * 1024 * 1024
    }).trim();

    if (!output) return null;

    const firstPipe = output.indexOf("|");
    const secondPipe = output.indexOf("|", firstPipe + 1);
    if (firstPipe < 0 || secondPipe < 0) return null;

    const mime = output.slice(0, firstPipe);
    const ext = output.slice(firstPipe + 1, secondPipe);
    const base64 = output.slice(secondPipe + 1);

    if (!mime || !ext || !base64) return null;

    return { mime, ext, base64 };
  } catch {
    return null;
  }
}

function writeMacImageFileClipboard(filePath) {
  if (process.platform !== "darwin") return false;

  const binary = ensureMacHelper();
  if (!binary) return false;

  try {
    require("child_process").execFileSync(binary, ["write-image-file", filePath], {
      stdio: "ignore",
      timeout: 1500
    });
    return true;
  } catch {
    return false;
  }
}

function writeMacFileClipboard(paths) {
  if (process.platform !== "darwin") return false;

  const binary = ensureMacHelper();
  if (!binary) return false;

  try {
    require("child_process").execFileSync(binary, ["write", ...paths], {
      stdio: "ignore",
      timeout: 1500
    });
    return true;
  } catch {
    return false;
  }
}

function getWindowsFileClipboard() {
  // Windows file clipboard support requires a native CF_HDROP bridge.
  // Keep the app functional for text/images; Windows file pasting is
  // handled by the native helper in a later platform-specific build.
  return [];
}

function readFileClipboard() {
  if (process.platform === "darwin") return readMacFileClipboard();
  if (process.platform === "win32") return getWindowsFileClipboard();
  return [];
}

function stageReceivedFile(item, fileIndex) {
  const file = item.files[fileIndex];
  if (!file || !file.name || !file.contentBase64) return null;

  const filename = safeFilename(file.name);
  const id = crypto.randomUUID();
  const destination = path.join(historyDir(), `${id}-${filename}`);

  const buffer = Buffer.from(file.contentBase64, "base64");

  if (buffer.length > MAX_FILE_SIZE) {
    throw new Error(`${filename} exceeds the 100 MB limit.`);
  }

  fs.writeFileSync(destination, buffer);

  return {
    id,
    name: filename,
    size: buffer.length,
    sha256: crypto.createHash("sha256").update(buffer).digest("hex"),
    localPath: destination
  };
}

function receiveRemoteFileItem(item) {
  if (!Array.isArray(item.files)) return null;

  const stagedFiles = [];
  for (let i = 0; i < item.files.length; i++) {
    const staged = stageReceivedFile(item, i);
    if (staged) stagedFiles.push(staged);
  }

  if (!stagedFiles.length) return null;

  return {
    ...item,
    files: stagedFiles,
    fingerprint: fileFingerprint(stagedFiles)
  };
}

function fileItemForNetwork(item) {
  return {
    id: item.id,
    kind: "file",
    createdAt: item.createdAt,
    sourceName: item.sourceName,
    fingerprint: item.fingerprint,
    files: item.files.map(f => ({
      name: f.name,
      size: f.size,
      sha256: f.sha256,
      contentBase64: fs.readFileSync(f.localPath).toString("base64")
    }))
  };
}

function sendFileItem(item) {
  broadcast({
    type: "file-item",
    item: fileItemForNetwork(item)
  });
}

function createTextHistory(text) {
  return {
    id: crypto.randomUUID(),
    kind: "text",
    data: text,
    createdAt: new Date().toISOString(),
    sourceName: os.hostname(),
    fingerprint: hashData("text", text)
  };
}

function createImageHistory(image) {
  const data = image.toDataURL();
  return {
    id: crypto.randomUUID(),
    kind: "image",
    data,
    createdAt: new Date().toISOString(),
    sourceName: os.hostname(),
    fingerprint: hashData("image", data)
  };
}

function broadcastClipboardItem(item) {
  broadcast({
    type: "clipboard",
    item
  });
}

function getClipboardFingerprint() {
  const files = readFileClipboard();

  if (files.length) {
    const metadata = files.map(filePath => {
      try {
        const stat = fs.statSync(filePath);
        return `${filePath}:${stat.size}:${stat.mtimeMs}`;
      } catch {
        return filePath;
      }
    }).join("|");

    return {
      kind: "file",
      fingerprint: hashData("file", metadata),
      files
    };
  }

  const text = clipboard.readText();
  if (text) {
    return {
      kind: "text",
      fingerprint: hashData("text", text),
      text
    };
  }

  const macImage = readMacImageClipboard();
  if (macImage) {
    return {
      kind: "image-file",
      fingerprint: hashData("image-file", `${macImage.mime}:${macImage.base64}`),
      imageFile: macImage
    };
  }

  const image = clipboard.readImage();
  if (image && !image.isEmpty()) {
    const data = image.toDataURL();
    return {
      kind: "image",
      fingerprint: hashData("image", data),
      image
    };
  }

  return null;
}

function pollClipboard() {
  if (suppressNextClipboardPoll) {
    suppressNextClipboardPoll = false;
    return;
  }

  try {
    const current = getClipboardFingerprint();
    if (!current) return;

    if (current.fingerprint === lastClipboardFingerprint) return;
    lastClipboardFingerprint = current.fingerprint;

    if (current.kind === "file") {
      const copiedFiles = copyFilesToHistory(current.files);
      if (!copiedFiles.length) return;

      const item = {
        id: crypto.randomUUID(),
        kind: "file",
        files: copiedFiles,
        createdAt: new Date().toISOString(),
        sourceName: os.hostname(),
        fingerprint: fileFingerprint(copiedFiles)
      };

      if (addHistoryItem(item, false)) {
        sendFileItem(item);
        activity(`Synced ${copiedFiles.length} file${copiedFiles.length === 1 ? "" : "s"}`);
      }
      return;
    }

    if (current.kind === "text") {
      const item = createTextHistory(current.text);
      if (addHistoryItem(item, false)) {
        broadcastClipboardItem(item);
        activity("Synced text");
      }
      return;
    }

    if (current.kind === "image-file") {
      const imageBuffer = Buffer.from(current.imageFile.base64, "base64");
      if (imageBuffer.length > MAX_FILE_SIZE) {
        activity("Image is larger than the 100 MB limit.");
        return;
      }

      const id = crypto.randomUUID();
      const ext = safeFilename(current.imageFile.ext || "img");
      const filename = `clipboard-image-${id}.${ext}`;
      const destination = path.join(historyDir(), filename);
      fs.writeFileSync(destination, imageBuffer);

      const file = {
        id,
        name: filename,
        size: imageBuffer.length,
        sha256: crypto.createHash("sha256").update(imageBuffer).digest("hex"),
        localPath: destination,
        mime: current.imageFile.mime
      };

      const item = {
        id,
        kind: "image-file",
        file,
        createdAt: new Date().toISOString(),
        sourceName: os.hostname(),
        fingerprint: current.fingerprint
      };

      if (addHistoryItem(item, false)) {
        broadcast({
          type: "image-file-item",
          item: {
            id: item.id,
            kind: item.kind,
            file: {
              name: file.name,
              size: file.size,
              sha256: file.sha256,
              mime: file.mime,
              contentBase64: imageBuffer.toString("base64")
            },
            createdAt: item.createdAt,
            sourceName: item.sourceName,
            fingerprint: item.fingerprint
          }
        });
        activity(`Synced image as ${file.name}`);
      }
      return;
    }

    if (current.kind === "image") {
      const item = createImageHistory(current.image);
      if (addHistoryItem(item, false)) {
        broadcastClipboardItem(item);
        activity("Synced image");
      }
    }
  } catch (err) {
    activity(`Clipboard error: ${err.message}`);
  }
}

function receiveRemoteImageFileItem(item) {
  if (!item?.file?.contentBase64) return null;

  const buffer = Buffer.from(item.file.contentBase64, "base64");
  if (buffer.length > MAX_FILE_SIZE) {
    throw new Error("Image exceeds the 100 MB limit.");
  }

  const id = crypto.randomUUID();
  const filename = safeFilename(item.file.name || `clipboard-image-${id}.img`);
  const destination = path.join(historyDir(), `${id}-${filename}`);
  fs.writeFileSync(destination, buffer);

  return {
    ...item,
    id: crypto.randomUUID(),
    file: {
      id,
      name: filename,
      size: buffer.length,
      sha256: crypto.createHash("sha256").update(buffer).digest("hex"),
      localPath: destination,
      mime: item.file.mime
    }
  };
}

function applyRemoteClipboard(item) {
  if (!item) return;

  suppressNextClipboardPoll = true;

  try {
    if (item.kind === "image-file") {
      if (process.platform === "darwin" && item.file?.localPath) {
        if (!writeMacImageFileClipboard(item.file.localPath)) {
          throw new Error("Could not put image file on the macOS pasteboard.");
        }
        lastClipboardFingerprint = item.fingerprint;
        return;
      }

      // Fallback for non-macOS builds: expose the image as normal image data
      // if possible.
      if (item.file?.localPath) {
        const buffer = fs.readFileSync(item.file.localPath);
        const mime = item.file.mime || "image/png";
        const dataUrl = `data:${mime};base64,${buffer.toString("base64")}`;
        clipboard.writeImage(nativeImage.createFromDataURL(dataUrl));
        lastClipboardFingerprint = item.fingerprint;
        return;
      }
    }

    if (item.kind === "text") {
      clipboard.writeText(item.data || "");
      lastClipboardFingerprint = hashData("text", item.data || "");
      return;
    }

    if (item.kind === "image") {
      const image = nativeImage.createFromDataURL(item.data);
      clipboard.writeImage(image);
      lastClipboardFingerprint = hashData("image", item.data);
      return;
    }

    if (item.kind === "file") {
      const paths = item.files
        .map(f => f.localPath)
        .filter(Boolean);

      if (process.platform === "darwin") {
        if (!writeMacFileClipboard(paths)) {
          throw new Error("Could not put files onto the macOS Finder clipboard.");
        }
        lastClipboardFingerprint = item.fingerprint;
        return;
      }

      if (process.platform === "win32") {
        // Native Windows bridge is intentionally not claimed here.
        // Put the first file path as text rather than pretending it is
        // a Finder/Explorer file clipboard.
        clipboard.writeText(paths.join("\n"));
        lastClipboardFingerprint = item.fingerprint;
        return;
      }

      clipboard.writeText(paths.join("\n"));
      lastClipboardFingerprint = item.fingerprint;
    }
  } catch (err) {
    activity(`Could not apply remote clipboard: ${err.message}`);
  }
}

function handleMessage(peer, raw) {
  let message;
  try {
    message = JSON.parse(raw);
  } catch {
    return;
  }

  if (message.type === "hello") {
    activity(`Peer: ${message.hostname || peer.address}`);
    return;
  }

  if (message.type === "clipboard") {
    const item = message.item;
    if (!item) return;

    applyRemoteClipboard(item);

    const copy = {
      ...item,
      id: crypto.randomUUID(),
      sourceName: item.sourceName || peer.address
    };

    addHistoryItem(copy, false);
    activity(`Received ${item.kind}`);
    return;
  }

  if (message.type === "image-file-item") {
    try {
      const received = receiveRemoteImageFileItem(message.item);
      if (!received) return;

      applyRemoteClipboard(received);
      addHistoryItem(received, false);
      activity("Received image file");
    } catch (err) {
      activity(`Image receive failed: ${err.message}`);
    }
    return;
  }

  if (message.type === "file-item") {
    try {
      const received = receiveRemoteFileItem(message.item);
      if (!received) return;

      applyRemoteClipboard(received);

      addHistoryItem(received, false);
      activity(`Received ${received.files.length} file${received.files.length === 1 ? "" : "s"}`);
    } catch (err) {
      activity(`File receive failed: ${err.message}`);
    }
    return;
  }

  if (message.type === "history-item") {
    const item = message.item;

    if (item?.kind === "file") {
      // History sync may contain file paths that don't exist on this machine.
      // Such remote historical files are skipped until the owner sends them
      // as an active file-item.
      return;
    }

    addHistoryItem({
      ...item,
      id: crypto.randomUUID()
    }, false);
    return;
  }

  if (message.type === "history-sync") {
    if (!Array.isArray(message.items)) return;

    for (const item of message.items) {
      if (item.kind === "file") continue;
      addHistoryItem({
        ...item,
        id: crypto.randomUUID()
      }, false);
    }
    return;
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 760,
    minWidth: 700,
    minHeight: 600,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, "index.html"));

  // The WebSocket server may start before the renderer finishes loading.
  // Send the current state once the page is actually ready so the UI never
  // gets stuck on "Loading...".
  mainWindow.webContents.on("did-finish-load", () => {
    pushState();
  });
}

ipcMain.handle("get-state", () => state());

ipcMain.handle("connect-to-ip", (_event, ip) => connectToIP(ip));

ipcMain.handle("copy-history-item", (_event, id) => {
  const item = history.find(x => x.id === id);
  if (!item) return { ok: false };

  try {
    suppressNextClipboardPoll = true;

    if (item.kind === "text") {
      clipboard.writeText(item.data);
      lastClipboardFingerprint = item.fingerprint;
      return { ok: true };
    }

    if (item.kind === "image") {
      clipboard.writeImage(nativeImage.createFromDataURL(item.data));
      lastClipboardFingerprint = item.fingerprint;
      return { ok: true };
    }

    if (item.kind === "image-file") {
      if (!item.file?.localPath || !fs.existsSync(item.file.localPath)) {
        return { ok: false, error: "Image file is no longer available." };
      }

      if (process.platform === "darwin") {
        const ok = writeMacImageFileClipboard(item.file.localPath);
        if (!ok) return { ok: false, error: "Could not put image file on the macOS pasteboard." };
        lastClipboardFingerprint = item.fingerprint;
        return { ok: true };
      }

      const buffer = fs.readFileSync(item.file.localPath);
      const mime = item.file.mime || "image/png";
      const dataUrl = `data:${mime};base64,${buffer.toString("base64")}`;
      clipboard.writeImage(nativeImage.createFromDataURL(dataUrl));
      lastClipboardFingerprint = item.fingerprint;
      return { ok: true };
    }

    if (item.kind === "file") {
      const paths = item.files.map(f => f.localPath).filter(p => p && fs.existsSync(p));

      if (!paths.length) return { ok: false, error: "File is no longer available." };

      if (process.platform === "darwin") {
        const ok = writeMacFileClipboard(paths);
        if (!ok) return { ok: false, error: "Could not put files on the macOS file clipboard." };
        lastClipboardFingerprint = item.fingerprint;
        return { ok: true };
      }

      clipboard.writeText(paths.join("\n"));
      return { ok: true, warning: "File clipboard is not implemented natively on this platform yet." };
    }
  } catch (err) {
    return { ok: false, error: err.message };
  }

  return { ok: false };
});

ipcMain.handle("delete-history-item", (_event, id) => {
  removeHistoryItem(id);
  return { ok: true };
});

ipcMain.handle("clear-history", () => {
  clearHistory();
  return { ok: true };
});

app.whenReady().then(() => {
  loadHistory();
  ensureDirs();
  createWindow();
  startWebSocketServer();

  setTimeout(() => {
    try {
      const initial = getClipboardFingerprint();
      lastClipboardFingerprint = initial?.fingerprint || null;
    } catch {}

    setInterval(pollClipboard, CLIPBOARD_POLL_MS);
  }, 1000);

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
