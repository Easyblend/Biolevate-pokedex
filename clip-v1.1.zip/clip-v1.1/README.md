# Clip v1.1

A tiny LAN clipboard sync app.

## What this version does

- Runs a WebSocket server on each laptop.
- Uses direct IP connection instead of relying on UDP broadcast discovery.
- Syncs copied text.
- Syncs copied images.
- Shows connection state.
- No cloud server.
- No account.
- No database.

## Run

Install Node.js 20+.

Then:

```bash
npm install
npm start
```

Run Clip on both laptops.

### Connect the laptops

On Laptop A, enter Laptop B's IP address.

Example:

```text
10.100.195.65
```

On Laptop B, enter Laptop A's IP address.

Example:

```text
10.100.195.60
```

Click **Connect**.

The connection uses:

```text
ws://IP_ADDRESS:45821
```

## Testing

1. Connect both laptops.
2. Copy text on Laptop A.
3. Paste on Laptop B.
4. Copy an image on Laptop B.
5. Paste on Laptop A.

## Firewall

If the connection fails despite ping working, the OS firewall may be blocking TCP port 45821.

Allow Node/Electron/Clip to accept local network connections.

## Current limitation

Images are sent as base64-encoded PNG data. This is deliberately simple for the MVP. Large images should later use binary WebSocket frames/chunking and optional compression.

## Next

- mDNS/Bonjour automatic discovery
- Secure pairing
- Encryption
- System tray/background mode
- Clipboard history
- Cross-platform installers
