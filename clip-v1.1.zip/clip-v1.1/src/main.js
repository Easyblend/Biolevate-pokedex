const {
  app,
  BrowserWindow,
  clipboard,
  nativeImage,
  ipcMain
} = require("electron");

const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { WebSocketServer, WebSocket } = require("ws");

const WS_PORT = 45821;
const CLIPBOARD_POLL_MS = 400;

const DEVICE_ID = crypto.randomUUID();
const DEVICE_NAME = os.hostname();

let win;
let wss;
let peers = new Map();

let lastClipboardHash = "";
let suppressClipboardUntil = 0;

function sendUI(channel, data = {}) {
  if (win && !win.isDestroyed()) {
    win.webContents.send(channel, data);
  }
}

function sha256(value) {
  return crypto
    .createHash("sha256")
    .update(value)
    .digest("hex");
}

function getLocalIPv4Addresses() {
  const addresses = [];

  for (const interfaces of Object.values(os.networkInterfaces())) {
    for (const network of interfaces || []) {
      if (
        network.family === "IPv4" &&
        !network.internal
      ) {
        addresses.push(network.address);
      }
    }
  }

  return addresses;
}

/* ---------------- WebSocket server ---------------- */

function startWebSocketServer() {
  wss = new WebSocketServer({
    host: "0.0.0.0",
    port: WS_PORT
  });

  wss.on("listening", () => {
    sendUI("status", {
      text: `Listening on WebSocket port ${WS_PORT}`
    });
  });

  wss.on("connection", (socket, request) => {
    const remoteIP =
      request.socket.remoteAddress?.replace("::ffff:", "") || "unknown";

    socket._clipPeerIP = remoteIP;

    socket.on("message", raw => {
      try {
        const message = JSON.parse(raw.toString());

        if (message.type === "hello") {
          socket._clipPeerId = message.deviceId;
          socket._clipPeerName = message.name || remoteIP;

          sendUI("peer-update", {
            id: message.deviceId || `remote-${remoteIP}`,
            name: message.name || remoteIP,
            ip: remoteIP,
            connected: true
          });

          socket.send(
            JSON.stringify({
              type: "hello",
              deviceId: DEVICE_ID,
              name: DEVICE_NAME
            })
          );

          return;
        }

        if (
          message.type === "clipboard" &&
          message.source !== DEVICE_ID
        ) {
          applyRemoteClipboard(message);
        }
      } catch (error) {
        sendUI("status", {
          text: `Received invalid message: ${error.message}`
        });
      }
    });

    socket.on("close", () => {
      const id =
        socket._clipPeerId || `manual-${remoteIP}`;

      sendUI("peer-update", {
        id,
        name: socket._clipPeerName || remoteIP,
        ip: remoteIP,
        connected: false
      });

      const peer = peers.get(id);

      if (peer && peer.socket === socket) {
        peer.socket = null;
      }
    });
  });

  wss.on("error", error => {
    sendUI("status", {
      text: `WebSocket server error: ${error.message}`
    });
  });
}

/* ---------------- Direct IP connection ---------------- */

function connectToIP(ip) {
  const id = `manual-${ip}`;

  let peer = peers.get(id);

  if (!peer) {
    peer = {
      id,
      name: ip,
      ip,
      socket: null,
      connecting: false
    };

    peers.set(id, peer);
  }

  if (
    peer.socket &&
    peer.socket.readyState === WebSocket.OPEN
  ) {
    sendUI("status", {
      text: `Already connected to ${ip}`
    });
    return;
  }

  if (peer.connecting) {
    return;
  }

  peer.connecting = true;

  sendUI("status", {
    text: `Connecting to ${ip}:${WS_PORT}…`
  });

  const socket = new WebSocket(
    `ws://${ip}:${WS_PORT}`
  );

  socket.on("open", () => {
    peer.socket = socket;
    peer.connecting = false;

    socket.send(
      JSON.stringify({
        type: "hello",
        deviceId: DEVICE_ID,
        name: DEVICE_NAME
      })
    );

    sendUI("peer-update", {
      id,
      name: peer.name,
      ip,
      connected: true
    });

    sendUI("status", {
      text: `Connected to ${ip}`
    });
  });

  socket.on("message", raw => {
    try {
      const message = JSON.parse(raw.toString());

      if (message.type === "hello") {
        peer.name = message.name || ip;

        sendUI("peer-update", {
          id,
          name: peer.name,
          ip,
          connected: true
        });

        return;
      }

      if (
        message.type === "clipboard" &&
        message.source !== DEVICE_ID
      ) {
        applyRemoteClipboard(message);
      }
    } catch {}
  });

  socket.on("close", () => {
    peer.socket = null;
    peer.connecting = false;

    sendUI("peer-update", {
      id,
      name: peer.name,
      ip,
      connected: false
    });

    sendUI("status", {
      text: `Disconnected from ${peer.name}`
    });
  });

  socket.on("error", error => {
    peer.connecting = false;

    sendUI("peer-update", {
      id,
      name: peer.name,
      ip,
      connected: false
    });

    sendUI("status", {
      text: `Could not connect to ${ip}:${WS_PORT}`
    });
  });
}

/* ---------------- Clipboard sync ---------------- */

function broadcastClipboard(payload) {
  const message = JSON.stringify({
    type: "clipboard",
    source: DEVICE_ID,
    ...payload
  });

  let sent = 0;

  for (const peer of peers.values()) {
    if (
      peer.socket &&
      peer.socket.readyState === WebSocket.OPEN
    ) {
      peer.socket.send(message);
      sent++;
    }
  }

  return sent;
}

function applyRemoteClipboard(message) {
  suppressClipboardUntil =
    Date.now() + 1200;

  if (message.kind === "text") {
    clipboard.writeText(message.data);

    sendUI("received", {
      kind: "text",
      preview: message.data.slice(0, 100)
    });

    return;
  }

  if (message.kind === "image") {
    const image =
      nativeImage.createFromDataURL(message.data);

    if (!image.isEmpty()) {
      clipboard.writeImage(image);

      sendUI("received", {
        kind: "image",
        preview: "Image received"
      });
    }
  }
}

function pollClipboard() {
  if (Date.now() < suppressClipboardUntil) {
    return;
  }

  /*
   * Check text first.
   *
   * This means normal copied text is handled quickly.
   * If there is no text, we check for an image.
   */

  const text = clipboard.readText();

  if (text) {
    const currentHash =
      sha256(`text:${text}`);

    if (currentHash === lastClipboardHash) {
      return;
    }

    lastClipboardHash = currentHash;

    const sent = broadcastClipboard({
      kind: "text",
      data: text
    });

    sendUI("sent", {
      kind: "text",
      preview: text.slice(0, 100),
      sent
    });

    return;
  }

  const image = clipboard.readImage();

  if (!image.isEmpty()) {
    const png = image.toPNG();

    const currentHash =
      sha256(
        Buffer.concat([
          Buffer.from("image:"),
          png
        ])
      );

    if (currentHash === lastClipboardHash) {
      return;
    }

    lastClipboardHash = currentHash;

    const data =
      `data:image/png;base64,${png.toString("base64")}`;

    const sent = broadcastClipboard({
      kind: "image",
      data
    });

    sendUI("sent", {
      kind: "image",
      preview: "Image copied",
      sent
    });
  }
}

/* ---------------- Window ---------------- */

function createWindow() {
  win = new BrowserWindow({
    width: 600,
    height: 680,
    minWidth: 460,
    minHeight: 560,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile(
    path.join(__dirname, "index.html")
  );

  win.on("closed", () => {
    win = null;
  });
}

/* ---------------- App ---------------- */

app.whenReady().then(() => {
  createWindow();
  startWebSocketServer();

  ipcMain.on(
    "connect-to-ip",
    (_, rawIP) => {
      const ip = String(rawIP || "").trim();

      if (
        !/^(\d{1,3}\.){3}\d{1,3}$/.test(ip)
      ) {
        sendUI("status", {
          text: "Enter a valid IPv4 address."
        });
        return;
      }

      const octets = ip
        .split(".")
        .map(Number);

      if (
        octets.some(
          value => value < 0 || value > 255
        )
      ) {
        sendUI("status", {
          text: "Invalid IPv4 address."
        });
        return;
      }

      connectToIP(ip);
    }
  );

  setInterval(
    pollClipboard,
    CLIPBOARD_POLL_MS
  );

  sendUI("device-info", {
    name: DEVICE_NAME,
    ips: getLocalIPv4Addresses(),
    port: WS_PORT
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
