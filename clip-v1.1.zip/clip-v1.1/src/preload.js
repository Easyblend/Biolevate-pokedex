const {
  contextBridge,
  ipcRenderer
} = require("electron");

const allowedEvents = [
  "device-info",
  "peer-update",
  "sent",
  "received",
  "status"
];

contextBridge.exposeInMainWorld(
  "clip",
  {
    on(channel, callback) {
      if (!allowedEvents.includes(channel)) {
        return;
      }

      ipcRenderer.on(
        channel,
        (_, data) => callback(data)
      );
    },

    connect(ip) {
      ipcRenderer.send(
        "connect-to-ip",
        ip
      );
    }
  }
);
