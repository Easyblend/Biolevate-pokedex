const $ = id => document.getElementById(id);

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

function formatBytes(n) {
  if (!n) return "0 B";
  const units = ["B","KB","MB","GB"];
  let i = 0, x = n;
  while (x >= 1024 && i < units.length - 1) {
    x /= 1024; i++;
  }
  return `${x.toFixed(i ? 1 : 0)} ${units[i]}`;
}

function render(state) {
  $("device").textContent = state.hostname;
  $("server").textContent = `WebSocket: 0.0.0.0:${state.port}`;

  const peers = state.peers || [];
  $("peers").innerHTML = peers.length
    ? peers.map(p => `<div class="peer"><span class="mono">${esc(p.address)}</span> <span class="muted">connected</span></div>`).join("")
    : `<div class="empty">No connected laptops.</div>`;

  const items = state.history || [];
  if (!items.length) {
    $("history").innerHTML = `<div class="empty">Nothing copied yet.</div>`;
    return;
  }

  $("history").innerHTML = items.map(item => {
    let icon = "📝";
    let preview = "";
    let meta = "";

    if (item.kind === "image") {
      icon = `<img class="thumb" src="${esc(item.data)}">`;
      preview = "Image";
    } else if (item.kind === "file") {
      icon = `<div class="icon">📄</div>`;
      const names = (item.files || []).map(f => f.name).join(", ");
      preview = names || "File";
      meta = `${item.files?.length || 0} file(s)`;
      if (item.files?.[0]) meta += ` · ${formatBytes(item.files[0].size)}`;
    } else {
      icon = `<div class="icon">📝</div>`;
      preview = item.data || "";
    }

    const time = new Date(item.createdAt).toLocaleString();

    return `
      <div class="item" data-id="${esc(item.id)}">
        ${icon}
        <div class="content">
          <div class="preview">${esc(preview)}</div>
          <div class="meta">${esc(meta || time)}</div>
        </div>
        <button class="delete" data-delete="${esc(item.id)}">×</button>
      </div>
    `;
  }).join("");

  document.querySelectorAll(".item").forEach(el => {
    el.addEventListener("click", async e => {
      if (e.target.closest("[data-delete]")) return;
      const result = await window.clip.copyHistoryItem(el.dataset.id);
      if (!result?.ok && result?.error) alert(result.error);
    });
  });

  document.querySelectorAll("[data-delete]").forEach(btn => {
    btn.addEventListener("click", async e => {
      e.stopPropagation();
      await window.clip.deleteHistoryItem(btn.dataset.delete);
    });
  });
}

$("connect").addEventListener("click", async () => {
  const ip = $("ip").value.trim();
  const result = await window.clip.connect(ip);
  if (result?.error) alert(result.error);
});

$("ip").addEventListener("keydown", e => {
  if (e.key === "Enter") $("connect").click();
});

$("clear").addEventListener("click", async () => {
  if (confirm("Clear all clipboard history?")) {
    await window.clip.clearHistory();
  }
});

window.clip.on("state", render);

// Explicitly request the current state after the renderer is ready.
// This avoids missing the initial state event during app startup.
window.clip.getState().then(render).catch(err => {
  console.error("Could not load Clip state:", err);
  $("device").textContent = "Could not load app state";
});

window.clip.on("activity", event => {
  const row = document.createElement("div");
  row.textContent = `[${new Date(event.timestamp).toLocaleTimeString()}] ${event.message}`;
  $("activity").prepend(row);

  while ($("activity").children.length > 80) {
    $("activity").lastChild.remove();
  }
});